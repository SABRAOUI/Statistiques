<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
    <ul>
        <li class="active"><a href="index.html"><i class="icon icon-signal"></i> <span>Statistique</span></a> </li>
    </ul>
</div>
<!--sidebar-menu-->