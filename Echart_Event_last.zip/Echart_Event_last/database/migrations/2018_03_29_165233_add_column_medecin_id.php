<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnMedecinId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('doc_evenements', function (Blueprint $table) {
            $table->integer('medecin_id')->unsigned()->after('start');
            $table->foreign('medecin_id')->references('id')->on('doc_medecins');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('doc_evenements', function (Blueprint $table) {
            $table->dropForeign(['medecin_id']);
            $table->dropColumn(['medecin_id']);
//            $table->date('date','start')->change();
        });
    }
}
