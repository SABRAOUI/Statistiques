<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnVilleId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('doc_medecins', function (Blueprint $table) {
            $table->integer('ville_id')->after('inscrit');
            $table->foreign('ville_id')->references('id')->on('doc_villes');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('doc_medecins', function (Blueprint $table) {
            $table->dropForeign(['ville_id']);
            $table->dropColumn(['ville_id']);
        });
    }
}
