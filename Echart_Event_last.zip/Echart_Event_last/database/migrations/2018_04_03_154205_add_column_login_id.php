<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnLoginId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('doc_patients', function (Blueprint $table) {
            $table->integer('login_id')->unsigned()->after('date');
            $table->foreign('login_id')->references('id')->on('doc_patients');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('doc_patients', function (Blueprint $table) {
            $table->dropForeign(['login_id']);
            $table->dropColumn(['login_id']);
        });
    }
}
