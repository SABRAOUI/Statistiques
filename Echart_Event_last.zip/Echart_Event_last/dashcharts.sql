-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 06 avr. 2018 à 12:18
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dashcharts`
--

-- --------------------------------------------------------

--
-- Structure de la table `doc_evenements`
--

DROP TABLE IF EXISTS `doc_evenements`;
CREATE TABLE IF NOT EXISTS `doc_evenements` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `start` date NOT NULL,
  `medecin_id` int(10) UNSIGNED NOT NULL,
  `patient_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `doc_evenements_medecin_id_foreign` (`medecin_id`),
  KEY `doc_evenements_patient_id_foreign` (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_evenements`
--

INSERT INTO `doc_evenements` (`id`, `start`, `medecin_id`, `patient_id`) VALUES
(1, '2018-02-08', 1, 2),
(2, '2018-02-09', 3, 4),
(3, '2018-02-07', 1, 3),
(4, '2018-02-09', 2, 8),
(5, '2018-04-11', 4, 9),
(6, '2018-04-12', 5, 12),
(7, '2018-04-14', 6, 14),
(8, '2018-04-19', 7, 5),
(9, '2018-04-23', 8, 11),
(10, '2018-03-23', 6, 2),
(11, '2018-03-28', 6, 4),
(12, '2018-03-29', 4, 14),
(13, '2018-03-18', 9, 12),
(14, '2018-04-01', 10, 10),
(15, '2018-02-08', 1, 2),
(16, '2018-02-08', 2, 4),
(17, '2018-02-08', 1, 3),
(18, '2018-02-09', 6, 8),
(19, '2018-04-11', 10, 14),
(20, '2018-04-11', 8, 12),
(21, '2018-04-19', 5, 8),
(22, '2018-04-19', 7, 13),
(23, '2018-04-29', 2, 7),
(24, '2018-04-29', 2, 7),
(25, '2018-04-29', 2, 7),
(26, '2018-04-29', 2, 7),
(27, '2018-03-23', 8, 6),
(28, '2018-03-23', 1, 9),
(29, '2018-03-29', 9, 1),
(30, '2018-03-29', 4, 7),
(31, '2018-03-29', 2, 3),
(32, '2018-03-29', 5, 4),
(33, '2018-03-18', 1, 5),
(34, '2018-03-18', 8, 2);

-- --------------------------------------------------------

--
-- Structure de la table `doc_logins`
--

DROP TABLE IF EXISTS `doc_logins`;
CREATE TABLE IF NOT EXISTS `doc_logins` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nb_cnx` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_logins`
--

INSERT INTO `doc_logins` (`id`, `nb_cnx`, `type`, `created_at`, `updated_at`) VALUES
(1, 20, 1, NULL, NULL),
(2, 30, 0, NULL, NULL),
(3, 45, 1, NULL, NULL),
(4, 15, 0, NULL, NULL),
(5, 60, 1, NULL, NULL),
(6, 55, 0, NULL, NULL),
(7, 20, 1, NULL, NULL),
(8, 30, 0, NULL, NULL),
(9, 35, 1, NULL, NULL),
(10, 40, 0, NULL, NULL),
(11, 42, 1, NULL, NULL),
(12, 80, 0, NULL, NULL),
(13, 40, 1, NULL, NULL),
(14, 30, 0, NULL, NULL),
(15, 12, 1, NULL, NULL),
(16, 50, 0, NULL, NULL),
(17, 40, 1, NULL, NULL),
(18, 25, 0, NULL, NULL),
(19, 61, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `doc_medecins`
--

DROP TABLE IF EXISTS `doc_medecins`;
CREATE TABLE IF NOT EXISTS `doc_medecins` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prénom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_id` int(10) UNSIGNED NOT NULL,
  `inscrit` int(11) NOT NULL,
  `ville_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doc_medecins_login_id_foreign` (`login_id`),
  KEY `doc_medecins_ville_id_foreign` (`ville_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_medecins`
--

INSERT INTO `doc_medecins` (`id`, `nom`, `prénom`, `login_id`, `inscrit`, `ville_id`, `created_at`, `updated_at`) VALUES
(1, 'Nasiri', 'Siham', 1, 0, 1, NULL, NULL),
(2, 'Alaoui', 'Karim', 3, 1, 1, NULL, NULL),
(3, 'Charqaoui', 'Salim', 5, 0, 1, NULL, NULL),
(4, 'Daoudi', 'Said', 7, 1, 2, NULL, NULL),
(5, 'Saidi', 'Monir', 9, 1, 6, NULL, NULL),
(6, 'Kadiri', 'Malika', 11, 0, 3, NULL, NULL),
(7, 'Sfyani', 'Imadd', 13, 1, 8, NULL, NULL),
(8, 'Jahid', 'Abderrahim', 15, 1, 8, NULL, NULL),
(9, 'Karni', 'Asma', 17, 1, 4, NULL, NULL),
(10, 'Banoud', 'Samir', 19, 1, 2, NULL, NULL),
(11, 'Samadi', 'Ali', 1, 1, 2, NULL, NULL),
(12, 'Morabit', 'Safa', 11, 1, 4, NULL, NULL),
(13, 'Amjahdi', 'Farid', 7, 1, 4, NULL, NULL),
(14, 'Raki', 'Hamid', 3, 1, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `doc_patients`
--

DROP TABLE IF EXISTS `doc_patients`;
CREATE TABLE IF NOT EXISTS `doc_patients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `login_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doc_patients_login_id_foreign` (`login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_patients`
--

INSERT INTO `doc_patients` (`id`, `date`, `login_id`, `created_at`, `updated_at`) VALUES
(1, '2018-03-08', 1, NULL, NULL),
(2, '2018-03-09', 2, NULL, NULL),
(3, '2018-03-07', 3, NULL, NULL),
(4, '2018-03-09', 8, NULL, NULL),
(5, '2018-03-11', 3, NULL, NULL),
(6, '2018-03-12', 4, NULL, NULL),
(7, '2018-03-14', 4, NULL, NULL),
(8, '2018-03-19', 5, NULL, NULL),
(9, '2018-03-23', 6, NULL, NULL),
(10, '2018-03-23', 9, NULL, NULL),
(11, '2018-03-28', 8, NULL, NULL),
(12, '2018-03-29', 9, NULL, NULL),
(13, '2018-04-18', 3, NULL, NULL),
(14, '2018-03-01', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `doc_villes`
--

DROP TABLE IF EXISTS `doc_villes`;
CREATE TABLE IF NOT EXISTS `doc_villes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ville` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_villes`
--

INSERT INTO `doc_villes` (`id`, `ville`, `created_at`, `updated_at`) VALUES
(1, 'casa', NULL, NULL),
(2, 'kech', NULL, NULL),
(3, 'rabat', NULL, NULL),
(4, 'nador', NULL, NULL),
(5, 'sala', NULL, NULL),
(6, 'tanger', NULL, NULL),
(7, 'titouan', NULL, NULL),
(8, 'dakhla', NULL, NULL),
(9, 'eljadoda', NULL, NULL),
(10, 'essaouira', NULL, NULL),
(11, 'laayoun', NULL, NULL),
(12, 'ouajda', NULL, NULL),
(13, 'mohamadia', NULL, NULL),
(14, 'agadir', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `doc_vu_profils`
--

DROP TABLE IF EXISTS `doc_vu_profils`;
CREATE TABLE IF NOT EXISTS `doc_vu_profils` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `medecin_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `doc_vu_profils_medecin_id_foreign` (`medecin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `doc_vu_profils`
--

INSERT INTO `doc_vu_profils` (`id`, `medecin_id`, `date`, `created_at`, `updated_at`) VALUES
(1, 1, '2018-04-05 00:00:00', NULL, NULL),
(2, 3, '2018-04-04 00:00:00', NULL, NULL),
(3, 1, '2018-04-03 00:00:00', NULL, NULL),
(4, 2, '2018-04-09 00:00:00', NULL, NULL),
(5, 4, '2018-03-11 00:00:00', NULL, NULL),
(6, 5, '2018-03-12 00:00:00', NULL, NULL),
(7, 6, '2018-03-14 00:00:00', NULL, NULL),
(8, 7, '2018-03-19 00:00:00', NULL, NULL),
(9, 8, '2018-03-23 00:00:00', NULL, NULL),
(10, 6, '2018-02-23 00:00:00', NULL, NULL),
(11, 6, '2018-02-28 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(34, '2014_10_12_000000_create_users_table', 4),
(35, '2014_10_12_100000_create_password_resets_table', 4),
(3, '2018_03_27_145206_create_doc_medecins_table', 2),
(4, '2018_03_27_172611_create_doc_evenements_table', 3),
(36, '2018_03_29_164603_create_doc_medecins_table', 4),
(37, '2018_03_29_164713_create_doc_evenements_table', 4),
(38, '2018_03_29_165233_add_column_medecin_id', 4),
(39, '2018_04_03_143108_create_doc_logins_table', 4),
(40, '2018_04_03_144802_add_column_login_id', 4),
(41, '2018_04_03_145750_create_doc_patients_table', 4),
(42, '2018_04_03_154205_add_column_login_id', 5),
(43, '2018_04_03_155021_create_doc_villes_table', 6),
(44, '2018_04_03_155951_add_column_ville_id', 7),
(45, '2018_04_03_212609_add_column_patient_id', 8),
(46, '2018_04_03_215419_create_doc_vu_prodils_table', 9),
(47, '2018_04_03_220057_create_doc_vu_profils_table', 10),
(48, '2018_04_03_220242_add_column_medecin_id', 11);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
