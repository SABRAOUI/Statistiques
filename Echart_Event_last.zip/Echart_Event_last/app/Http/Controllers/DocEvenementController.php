<?php

namespace App\Http\Controllers;

use App\Doc_evenement;
use App\Doc_medecin;
use Carbon\Carbon;
use Illuminate\Http\Request;
use DB;

class DocEvenementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //10 médecins Top
        $medecinsTop = DB::table('doc_evenements')
            ->leftJoin('doc_medecins', 'doc_evenements.medecin_id', 'doc_medecins.id')
            ->select('medecin_id','nom',DB::raw('count(*) as total'))
            ->groupby('medecin_id')
            ->orderby('total','desc')
            ->take(10)
            ->get();

        //Inscription des médecins
        $insc_med = DB::table('doc_medecins')
            ->select('*', 'inscrit',DB::raw('count(*) as totalnsc'))
            ->groupby('inscrit')
            ->get();

        //Nombre medcins/ville
        $vu = DB::table('doc_medecins')
            ->leftJoin('doc_villes', 'doc_medecins.ville_id', 'doc_villes.id')
            ->select('ville_id','ville',DB::raw('count(*) as TotalVus'))
            ->groupby('ville_id')
            ->get();

        //Nombre vue/ville :
        $vus_ville = DB::table('doc_villes')
            ->join('doc_medecins', 'doc_villes.id', '=', 'doc_medecins.ville_id')
            ->join('doc_vu_profils', 'doc_medecins.id', '=', 'doc_vu_profils.medecin_id')
            ->select('doc_villes.ville', DB::raw('count(doc_vu_profils.id) as TotalVusVille'))
            ->groupby('doc_villes.ville')
            ->get();
//        dd($vus_ville);

        //Nombre de cnx
        $nbr_cnx = DB::table('doc_medecins')
            ->leftJoin('doc_logins', 'doc_medecins.login_id', 'doc_logins.id')
            ->select('*','nom')
            ->groupby('nom')
            ->orderby('nb_cnx','desc')
            ->take(10)
            ->get();

        //Médecins et nombre des vus
        $medcin_vu = DB::table('doc_vu_profils')
            ->leftJoin('doc_medecins', 'doc_vu_profils.medecin_id', 'doc_medecins.id')
            ->select('*','nom',DB::raw('count(*) as TotMedVus'))
            ->groupby('nom')
            ->orderby('TotMedVus','desc')
            ->take(10)
            ->get();

        //Nombre RDV/jour
        $nb_rdv = DB::table('doc_evenements')
            ->select('start',DB::raw('count(*) as totalRDV'))
            ->groupby('start')
            ->orderby('start')
            ->get();
//        $x = Carbon::createFromFormat('m-d', $nb_rdv);

        //Nombre visiteurs/jour
        $nb_vis = DB::table('doc_vu_profils')
            ->select('date',DB::raw('count(*) as totalVisite'))
            ->groupby('date')
            ->orderby('date')
            ->get();
//        dd($nb_vis);

        //Nombre patients/jour
        $nb_pat = DB::table('doc_patients')
            ->select('date',DB::raw('count(*) as totalPat'))
            ->groupby('date')
            ->orderby('date')
            ->get();
//        dd($nb_pat);


        return view('admin.dashboard',['c_eve' => $medecinsTop,
                                            'insc' => $insc_med,
                                            'vus' => $vu,
                                            'cnx'=>$nbr_cnx,
                                            'med_vu'=>$medcin_vu,
                                            'vu_ville'=>$vus_ville,
                                            'nb_rdv'=>$nb_rdv,
                                            'nb_vis'=>$nb_vis,
                                            'nb_pat'=>$nb_pat
                                            ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Doc_evenement  $doc_evenement
     * @return \Illuminate\Http\Response
     */
    public function show(Doc_evenement $doc_evenement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Doc_evenement  $doc_evenement
     * @return \Illuminate\Http\Response
     */
    public function edit(Doc_evenement $doc_evenement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Doc_evenement  $doc_evenement
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doc_evenement $doc_evenement)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Doc_evenement  $doc_evenement
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doc_evenement $doc_evenement)
    {
        //
    }
}
