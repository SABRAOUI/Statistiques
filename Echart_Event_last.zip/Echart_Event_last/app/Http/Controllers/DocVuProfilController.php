<?php

namespace App\Http\Controllers;

use App\Doc_vu_profil;
use Illuminate\Http\Request;

class DocVuProfilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Doc_vu_profil  $doc_vu_profil
     * @return \Illuminate\Http\Response
     */
    public function show(Doc_vu_profil $doc_vu_profil)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Doc_vu_profil  $doc_vu_profil
     * @return \Illuminate\Http\Response
     */
    public function edit(Doc_vu_profil $doc_vu_profil)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Doc_vu_profil  $doc_vu_profil
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doc_vu_profil $doc_vu_profil)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Doc_vu_profil  $doc_vu_profil
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doc_vu_profil $doc_vu_profil)
    {
        //
    }
}
