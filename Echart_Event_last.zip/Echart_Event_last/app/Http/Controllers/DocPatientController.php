<?php

namespace App\Http\Controllers;

use App\doc_patient;
use Illuminate\Http\Request;

class DocPatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\doc_patient  $doc_patient
     * @return \Illuminate\Http\Response
     */
    public function show(doc_patient $doc_patient)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\doc_patient  $doc_patient
     * @return \Illuminate\Http\Response
     */
    public function edit(doc_patient $doc_patient)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\doc_patient  $doc_patient
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, doc_patient $doc_patient)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\doc_patient  $doc_patient
     * @return \Illuminate\Http\Response
     */
    public function destroy(doc_patient $doc_patient)
    {
        //
    }
}
