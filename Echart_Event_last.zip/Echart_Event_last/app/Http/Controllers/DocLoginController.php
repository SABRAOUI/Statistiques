<?php

namespace App\Http\Controllers;

use App\doc_login;
use Illuminate\Http\Request;

class DocLoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\doc_login  $doc_login
     * @return \Illuminate\Http\Response
     */
    public function show(doc_login $doc_login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\doc_login  $doc_login
     * @return \Illuminate\Http\Response
     */
    public function edit(doc_login $doc_login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\doc_login  $doc_login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, doc_login $doc_login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\doc_login  $doc_login
     * @return \Illuminate\Http\Response
     */
    public function destroy(doc_login $doc_login)
    {
        //
    }
}
