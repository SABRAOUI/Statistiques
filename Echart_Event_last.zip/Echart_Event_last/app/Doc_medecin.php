<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doc_medecin extends Model
{
    protected $fillable = ['nom', 'prénom','nombre_rdv'];

    public function doc_evenements(){
        return $this->hasMany('App\Doc_evenement');
    }
    public function doc_logins(){
        return $this->belongsTo('App\doc_login');
    }
    public function doc_villes(){
        return $this->belongsTo('App\Doc_ville');
    }
    public function doc_vu_profils(){
        return $this->hasMany('App\Doc_vu_profil');
    }
}
