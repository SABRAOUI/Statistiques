<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doc_ville extends Model
{
    public function doc_medecins(){
        return $this->hasMany('App\Doc_medecin');
    }
}
