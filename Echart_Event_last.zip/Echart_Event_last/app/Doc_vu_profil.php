<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doc_vu_profil extends Model
{
    public function doc_meds(){
        return $this->belongsTo('App\Doc_medecin');
    }
}
