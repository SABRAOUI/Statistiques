<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doc_evenement extends Model
{
    protected $fillable = ['id','start','medecin_id','patient_id'];
    protected $dates = ['start'];
    public function doc_med(){
        return $this->belongsTo('App\Doc_medecin');
    }
    public function doc_pat(){
        return $this->belongsTo('App\doc_patient');
    }

}
