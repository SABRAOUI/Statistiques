<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doc_patient extends Model
{
    public function doc_log(){
        return $this->belongsTo('App\doc_login');
    }
    public function doc_events(){
        return $this->hasMany('App\Doc_evenement');
    }
}
