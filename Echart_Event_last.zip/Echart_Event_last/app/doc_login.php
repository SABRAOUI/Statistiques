<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doc_login extends Model
{
    public function doc_medecins(){
        return $this->hasMany('App\Doc_medecin');
    }
    public function doc_patients(){
        return $this->hasMany('App\Doc_patient');
    }

}
