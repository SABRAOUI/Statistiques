<?php $__env->startSection('content'); ?>

<!--main-container-part-->
<div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb">
            <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
            <a href="#" class="current"><i class="icon-bar-chart"></i> Statistiques </a>
        </div>
        <h1>Statistiques des médecins et RDV</h1>
    </div>
    <!--End-breadcrumbs-->


    <div class="container-fluid">
        <hr>
        
        <div class="span8">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>10 Médecins top</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main"></div>
                </div>
            </div>
        </div>
        
        <div class="span5">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Inscription des médecins</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main2"></div>
                </div>
            </div>
        </div>
        
        <div class="span6">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre visiteurs/jour</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main3"></div>
                </div>
            </div>
        </div>
        <div class="span7">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre RDV/jour</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main4"></div>
                </div>
            </div>
        </div>
        <div class="span7" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre vue/ville</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main5"></div>
                </div>
            </div>
        </div>
        <div class="span6" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre Médecins/spécialité</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main6"></div>
                </div>
            </div>
        </div>
        <div class="span12" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre Patiens/jour</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main7"></div>
                </div>
            </div>
        </div>
        <div class="span6" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Nombre de connexion des médecines</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main8"></div>
                </div>
            </div>
        </div>
        <div class="span7" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Médecins/ville</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main11"></div>
                </div>
            </div>
        </div>


        <div class="span12" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Evolution du nombre des médecins</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main10"></div>
                </div>
            </div>
        </div>
        <div class="span12" >
            <div class="widget-box" >
                <div class="widget-title"> <span class="icon"> <i class="icon-signal"></i> </span>
                    <h5>Médecins/nombre des vues</h5>
                </div>
                <div class="widget-content">
                    <div class="bars" id="main9"></div>
                </div>
            </div>
        </div>


        <script type="text/javascript">
            //10 médecins top :
            var myChart = echarts.init(document.getElementById('main'));
            var option = {
                title: {
                    text: ''
                },
                tooltip: {},
                legend: {
                    data:['']
                },
                xAxis: {
                    data: ["Alaoui","Ahmadi","Benani","Charqui","Hilal","Berrada","Safani","Amrani","Kalam","Salmi"],
                },
                yAxis: {},
                series: [{
                    name: 'Docteur',
                    type: 'bar',
                    data: [82 , 67, 55, 48, 45, 37, 26, 18, 15, 8],
                }]
            };
            myChart.setOption(option);

            //Total des inscription :
            var myChart = echarts.init(document.getElementById('main2'));
            var option2 = {
                title : {
                    text: '',
                    subtext: 'Inscris/Non inscris',
                    x:'center'
                },
                tooltip : {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    data: ['non inscris','inscris']
                },
                series : [
                    {
                        name: 'Médecins',
                        type: 'pie',
                        radius : '55%',
                        center: ['50%', '60%'],
                        data:[
                            {value:335, name:'non inscris'},
                            {value:900, name:'inscris'}
                        ],
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            myChart.setOption(option2);

            //Nombre de visiteurs/jour au niveau de 3 mois :
            var dom = document.getElementById("main3");
            var myChart3 = echarts.init(dom);
            var option3 = {
                title: {
                    text: ''
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['Janvier','Février','Mars']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'Janvier',
                        type:'line',
                        stack: 'A',
                        data:[50, 97, 60, 40, 38, 45, 65,80,40,60,70,50,55,20,48,30,60,50,65,45,55,48,30,75,60,68,49,0,45,30,21]
                    },
                    {
                        name:'Février',
                        type:'line',
                        stack: 'B',
                        data:[50, 97, 80, 74, 38, 50, 80,25,58,60,55,50,75,70,65,30,45,67,65,68,75,40,50,42,50,68,12,50]
                    },
                    {
                        name:'Mars',
                        type:'line',
                        stack: 'C',
                        data:[ 25,75,60,15,75,70,48,30,75,60,80,30,45,38,68,50, 80,84,25,75,64,68,12,41,38,60,71,97, 45, 80,66]
                    },
                ]
            };
            myChart3.setOption(option3);

            //Nombre de rdv/jour au niveau de 3 mois :
            var dom = document.getElementById("main4");
            var myChart4 = echarts.init(dom);
            var option4 = {
                title: {
                    text: ''
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['Janvier','Février','Mars']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },

                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'Janvier',
                        type:'line',
                        stack: 'A',
                        data:[50, 97, 60, 40, 38, 45, 0,80,75,60,70,50,55,0,48,30,60,50,65,45,0,48,30,75,60,68,49,0,45,30,21]
                    },
                    {
                        name:'Février',
                        type:'line',
                        stack: 'B',
                        data:[50, 97, 80, 0, 38, 50, 80,25,75,60,0,50,75,70,65,30,45,0,65,68,75,40,50,42,0,68,12,50]
                    },
                    {
                        name:'Mars',
                        type:'line',
                        stack: 'C',
                        data:[ 25,75,60,0,75,70,48,30,75,60,0,30,45,38,68,50, 80,0,25,75,64,68,12,80,0,60,71,97, 45, 80,66]
                    },
                ]
            };
            myChart4.setOption(option4);

            //Nombre de vue / ville :
            var myChart5 = echarts.init(document.getElementById('main5'));
            var option5 = {
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b}: {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    x: 'left',
                    data:['Casa','Rabat','Marrakech','Eljadida','Tanger','Essaouira','Tantan','Dakhla','Laayoun','Ouajda']
                },
                series: [
                    {
                        name:'serie',
                        type:'pie',
                        selectedMode: 'single',
                        radius: [0, '30%'],

                        label: {
                            normal: {
                                position: 'inner'
                            }
                        },
                        labelLine: {
                            normal: {
                                show: false
                            }
                        },
                        data:[
                            {value:335, name:'', },
                            {value:679, name:''},
                            {value:1548, name:''}
                        ]
                    },
                    {   name:'vues',
                        type:'pie',
                        radius: ['40%', '55%'],
                        label: {
                            normal: {
                                formatter: ' {c}   ',

                                rich: {
                                    a: {
                                        color: '#999',
                                        lineHeight: 22,
                                        align: 'center'
                                    },
                                    // abg: {
                                    //     backgroundColor: '#333',
                                    //     width: '100%',
                                    //     align: 'right',
                                    //     height: 22,
                                    //     borderRadius: [4, 4, 0, 0]
                                    // },
                                    hr: {
                                        borderColor: '#aaa',
                                        width: '100%',
                                        borderWidth: 0.5,
                                        height: 0
                                    },
                                    b: {
                                        fontSize: 16,
                                        lineHeight: 33
                                    },
                                    per: {
                                        color: '#eee',
                                        backgroundColor: '#334455',
                                        padding: [2, 4],
                                        borderRadius: 2
                                    }
                                }
                            }
                        },
                        data:[
                            {value:335, name:'Casa'},
                            {value:310, name:'Rabat'},
                            {value:234, name:'Marrakech'},
                            {value:135, name:'Eljadida'},
                            {value:200, name:'Tanger'},
                            {value:300, name:'Essaouira'},
                            {value:400, name:'Tantan'},
                            {value:1000, name:'Dakhla'},
                            {value:100, name:'Laayoun'},
                            {value:450, name:'wajda'},
                        ]
                    }
                ]
            };
            myChart5.setOption(option5);

            //Nombre de méd / specialite :
            var myChart6 = echarts.init(document.getElementById('main6'));
            var option6 = {
                color: ['#3398DB'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {
                        type : 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis : [
                    {
                        type : 'category',
                        data: ["générale","gynécologie","radiologie","nucléaire","psychiatrie","immunologie","andrologie","neurologie","odontologie","obstétrique"],
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value'
                    }
                ],
                series : [
                    {
                        name:'',
                        type:'bar',
                        barWidth: '60%',
                        data:[10, 52, 200, 334, 390, 330, 220 , 390, 330, 220],
                    }
                ]
            };
            myChart6.setOption(option6);

            //Nombre de patiens/jour au niveau de 3 mois :
            var dom = document.getElementById("main7");
            var myChart7 = echarts.init(dom);
            var option7 = {
                xAxis: {
                    type: 'category',
                    data: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
                },
                yAxis: {
                    type: 'value'
                },
                legend: {
                    data:['Octobre','Novembre','Décembre']
                },
                series: [{
                    name:'Octobre',
                    data:[50, 97, 60, 40, 38, 45, 65,80,40,60,70,50,55,20,48,30,60,50,65,45,55,48,30,75,60,68,49,0,45,30,21],
                    type: 'line',
                    smooth: true
                },
                    {
                        name:'Novembre',
                        data:[ 25,75,60,15,75,70,48,30,75,60,80,30,45,38,68,50, 80,84,25,75,64,68,12,41,38,60,71,97, 45, 80,66],
                        type: 'line',
                        smooth: true
                    },
                    {
                        name:'Décembre',
                        data:[50, 97, 80, 74, 38, 50, 80,25,58,60,55,50,75,70,65,30,45,67,65,68,75,40,50,42,50,68,12,50],
                        type: 'line',
                        smooth: true
                    }
                ],

            };
            myChart7.setOption(option7);

            //Nombre de vue/ville au niveau de 3 mois :
            var dom = document.getElementById("main8");
            var myChart8 = echarts.init(dom);
            var option8 = {
                color: ['#3398DB'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {
                        type : 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis : [
                    {
                        type : 'category',
                        data: ["Hilal","Berrada","Saadi","Alaoui","Ahmadi","Benani","Charqui","Amrani","Kalam","Salmi"],
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value'
                    }
                ],
                series : [
                    {
                        name:'',
                        type:'bar',
                        barWidth: '60%',
                        data:[190, 52, 200, 100, 390, 100, 220 , 390, 280, 220],
                    }
                ]
            };
            myChart8.setOption(option8);

            //Evolution du nombre de medecins:
            var dom = document.getElementById("main9");
            var myChart9 = echarts.init(dom);
            var option9 = {
                color: ['#3398DB'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {
                        type : 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis : [
                    {
                        type : 'category',
                        data: ["Benani","Charqui","Amrani","Hilal","Berrada","Saadi","Alaoui","Ahmadi","Kalam","Salmi"],
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value'
                    }
                ],
                series : [
                    {
                        name:'',
                        type:'bar',
                        barWidth: '60%',
                        data:[220, 200, 280, 220,190, 52, 200, 100, 390, 100],
                    }
                ]
            };
            myChart9.setOption(option9);

            //Evolution du nombre de medecins:
            var dom = document.getElementById("main10");
            var myChart10 = echarts.init(dom);
            var option10 = {
                title: {
                    text: ''
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['Janvier','Février','Mars']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },

                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'Janvier',
                        type:'line',
                        stack: 'A',
                        data:[50, 97, 60, 40, 38, 45, 0,80,75,60,70,50,55,0,48,30,60,50,65,45,0,48,30,75,60,68,49,0,45,30,21]
                    },
                    {
                        name:'Février',
                        type:'line',
                        stack: 'B',
                        data:[50, 97, 80, 0, 38, 50, 80,25,75,60,0,50,75,70,65,30,45,0,65,68,75,40,50,42,0,68,12,50]
                    },
                    {
                        name:'Mars',
                        type:'line',
                        stack: 'C',
                        data:[ 25,75,60,0,75,70,48,30,75,60,0,30,45,38,68,50, 80,0,25,75,64,68,12,80,0,60,71,97, 45, 80,66]
                    },
                ]
            };
            myChart10.setOption(option10);

            //Evolution du nombre de medecins:
            var dom = document.getElementById("main11");
            var myChart11 = echarts.init(dom);
            var option11 = {
                title : {
                    text: '',
                    subtext: '',
                    x:'center'
                },
                tooltip : {
                    trigger: 'item',
                    formatter: "{b} : {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    data:['Casa','Rabat','Marrakech','Eljadida','Tanger','Essaouira','Tantan','Dakhla','Laayoun','Ouajda']

                },
                series : [
                    {
                        name: '',
                        type: 'pie',
                        radius : '55%',
                        center: ['50%', '60%'],
                        data:[
                            {value:335, name:'Casa'},
                            {value:310, name:'Rabat'},
                            {value:234, name:'Marrakech'},
                            {value:135, name:'Eljadida'},
                            {value:200, name:'Tanger'},
                            {value:300, name:'Essaouira'},
                            {value:400, name:'Tantan'},
                            {value:1000, name:'Dakhla'},
                            {value:100, name:'Laayoun'},
                            {value:450, name:'wajda'},
                        ],
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };

            myChart11.setOption(option11);

        </script>
    </div>
</div>
<!--end-main-container-part-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>